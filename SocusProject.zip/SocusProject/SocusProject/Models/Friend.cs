﻿using System.ComponentModel.DataAnnotations;

namespace SocusProject.Models
{
    public class Friend
    {
        [Key]
        public int FriendshipId { get; set; }
/*        public int FriendshipSentId { get; set; }
        public User FriendshipSent { get; set; }

        public int FriendshipRequestedId { get; set; }
        public User FriendshipRequested { get; set; }*/

        public FriendshipStatus FriendshipStatus { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd'/'MM'/'yyyy}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        public DateTime CreateDate { get; set; }
    }

    public enum FriendshipStatus
    {
        Pending = 0,
        Accepted = 1,
        Blocked = 2
    }
}
