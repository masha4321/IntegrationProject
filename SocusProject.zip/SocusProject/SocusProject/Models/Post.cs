﻿using System.ComponentModel.DataAnnotations;

namespace SocusProject.Models
{
    public class Post
    {
        [Key]
        public int Id { get; set; }

        public int UserID { get; set; }
        public User User { get; set; }
        public string Content { get; set; }
        public int Like { get; set; }
        public int Dislike { get; set; }
        public DateTime DateCreated { get; set; }
        /*public virtual ICollection<Comment> Comments { get; set; }*/

    }
}
