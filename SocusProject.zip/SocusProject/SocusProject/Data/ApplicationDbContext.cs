﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SocusProject.Models;

namespace SocusProject.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<SocusProject.Models.User>? User { get; set; }
        public DbSet<SocusProject.Models.Friend>? Friend { get; set; }
        public DbSet<SocusProject.Models.Post>? Post { get; set; }
        public DbSet<SocusProject.Models.Comment>? Comment { get; set; }
    }
}